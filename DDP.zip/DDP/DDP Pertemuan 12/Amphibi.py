from Animal import Animal

class Amphibi(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis_air, bernapas):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis_air = jenis_air
        self.bernafas = bernapas
        
    def info_amphibi(self):
        super().info_animal()
        print("jenis_air \t\t\t : ", self.jenis_air,
              "\nbernapas \t\t\t : ", self.bernafas)
        
    
print("==objek 1==")       
amphibi = Amphibi("Katak", "Serangga", "Dua alam", "Bertelur", "air tawar", "paruparu")
amphibi.info_amphibi()

print("==objek 2==")   
amphibi = Amphibi("Buaya", "Ikan", "Dua alam", "Bertelur", "air tawar", "paruparu")
amphibi.info_amphibi()

print("==objek 3==")   
amphibi = Amphibi("Kura-kura", "Tumbuhan", "Dua alam", "Bertelur", "air tawar", "paruparu")
amphibi.info_amphibi()