class Animal:
    def __init__(self, nama, makanan, hidup, berkembang_biak):
        self.nama = nama
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak
        
    def info_animal(self):
        print(f"Nama Hewan \t\t\t :", self.nama, 
              "\nmakanan \t\t\t : ", self.makanan, 
              "\nhidup \t\t\t\t : ", self.hidup, 
              "\nberkembang biak \t\t :", self.berkembang_biak)
        
# hewan = Animal ("Kucing garong", "Cimol", "Udara", "Bertelur")
# hewan.info_animal()
