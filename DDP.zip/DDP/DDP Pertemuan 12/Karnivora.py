from Animal import Animal

class Karnivora(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, jenis_gigi, fisik):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.jenis_gigi = jenis_gigi
        self.fisik = fisik
        
    def info_karnivora(self):
        super().info_animal()
        print("jenis_gigi \t\t\t : ", self.jenis_gigi,
              "\nfisik \t\t\t\t : ", self.fisik)
        
    
print("==objek 1==")       
karnivora = Karnivora("harimau", "daging", "Darat", "melahirkan", "besar", "berbulu")
karnivora.info_karnivora()

print("==objek 2==")   
karnivora = Karnivora("Singa", "Daging", "Darat", "melahirkan", "besar", "berbulu")
karnivora.info_karnivora()

print("==objek 3==")   
karnivora = Karnivora("Hiu", "ikan kecil", "Air", "melahirkan", "besar", "tidak berbulu")
karnivora.info_karnivora()